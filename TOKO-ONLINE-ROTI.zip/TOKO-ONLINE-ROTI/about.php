<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2 style=" width: 100%; border-bottom: 4px solidrgb(255, 83, 3)"><b>Tentang Kami</b></h2>
	<p class="text-justify">Unesa Cake & Bakery adalah salah satu bisnis roti modern di Indonesia yang berkomitmen menyajikan produk berkualitas tinggi kepada masyarakat. Didirikan pada tahun 2025, usaha ini beroperasi di bawah naungan PT. Unesa Cinta Rasa. Kami menghadirkan beragam pilihan roti yang sehat, bergizi, dan terjangkau, sehingga dapat dinikmati oleh semua kalangan. Dengan semangat inovasi dan pelayanan terbaik, kami terus berkembang untuk menjadi pilihan utama masyarakat dalam kebutuhan roti harian..</p>
</div>




 <?php 
	include 'footer.php';
 ?>