
	<footer style="border-top: 4px solidrgb(255, 89, 0);  ">
		<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4">
					<h3 style="color:rgb(0, 0, 0)"><b>UNESA - CAKE BAKERY</b></h3>
					<p>Jl. Ketintang, Ketintang, Kec.Gayungan, Surabaya, Jawa Timur</p>
					<p><i class="glyphicon glyphicon-earphone"></i> +6285855094087</p>
					<p><i class="glyphicon glyphicon-envelope"></i> unesa-cakebakery@gmail.com</p>
				</div>
				<div class="col-md-4">
					<h5><b>Menu</b></h5>
					<p><a href=""  style="color: #000">Produk</a></p>
					<p><a href=""  style="color: #000">Tentang kami</a></p>
					<p><a href=""  style="color: #000">Hubungi Kami</a></p>
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color:rgb(255, 89, 0); padding: 5px; color: #fff; text-align: center;">
			<span>Copyright&copy; Universitas Negeri Surabaya</span>
		</div>
	</footer>

</body>
</html>